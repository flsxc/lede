#!/bin/bash

source venv/bin/activate
python run_1.py

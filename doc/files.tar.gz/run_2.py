import argparse
from modules.worker import setup_models, process_task
import os
import configparser
from datetime import datetime  # 导入 datetime 模块

def normalize_path(path):
    return os.path.normpath(path)

def validate_folder_path(folder_path: str):
    folder_path = normalize_path(folder_path)
    if not os.path.isdir(folder_path):
        raise argparse.ArgumentTypeError(f"{folder_path} is not a valid path")
    return folder_path

def main():
    # Set up models before entering the main loop
    setup_models()

    # Create a config parser and read the configuration file
    config = configparser.ConfigParser()
    config.read('config_2.ini')

    # Extract the paths from the configuration file
    source = validate_folder_path(config.get('PATHS', 'source'))
    target = validate_folder_path(config.get('PATHS', 'target'))
    output = validate_folder_path(config.get('PATHS', 'output'))

    try:
        # Print the current time and a starting message
        print("Beginning at", datetime.now())

        # Call process_task with the provided folder paths
        process_task(target, source, output, "localtest")

        # Print the current time and an ending message
        print("Ended at", datetime.now())

    except KeyboardInterrupt:
        print("Exiting...")
        exit()

    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()


#!/bin/bash

source venv/bin/activate
python run_2.py
